package com.example.assignment3;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class DepositFragment extends Fragment {


    public DepositFragment() {
        // Required empty public constructor
    }

View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_deposit, container, false);

        final Button startDisplayAccountActivity = view.findViewById(R.id.makeDepositButton);
        startDisplayAccountActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText depositmoney = view.findViewById(R.id.depositAmount);
                String data =depositmoney.getText().toString();
                int money = Integer.parseInt(data);
                MyData.getInstant().depositMoney(money);
                Toast.makeText(getActivity(), getString(R.string.depositmade), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), DepositActivity.class);
                getActivity().finish();
            }
        });
        return view;
    }

}
