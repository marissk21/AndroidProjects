package com.example.assignment3;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 */
public class NameBalanceFragment extends Fragment {


    public NameBalanceFragment() {
        // Required empty public constructor
    }

View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_name_balance, container, false);

        Button startDepositActivity = view.findViewById(R.id.depositButton);
        startDepositActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText accountName = view.findViewById(R.id.editAccount);
                String accName = accountName.getText().toString();
                EditText accountNumber = view.findViewById(R.id.balanceAmount);
                String accountNum = accountNumber.getText().toString();
                int accNum = Integer.parseInt(accountNum);
                MyData.getInstant().setAccountName(accName);
                MyData.getInstant().setAccountNum(accNum);
                Intent intent = new Intent(getActivity(), DepositActivity.class);
                startActivity(intent);
            }
        });

       Button startWithdrawalActivity = view.findViewById(R.id.withdrawButton);
        startWithdrawalActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText description = view.findViewById(R.id.descriptionText);
                String descrip = description.getText().toString();
                EditText accountName = view.findViewById(R.id.editAccount);
                String accName = accountName.getText().toString();
                EditText accountNumber = view.findViewById(R.id.balanceAmount);
                String accountNum = accountNumber.getText().toString();
                int accNum = Integer.parseInt(accountNum);
                MyData.getInstant().setDescription(descrip);
                MyData.getInstant().setAccountName(accName);
                MyData.getInstant().setAccountNum(accNum);

                Intent intent = new Intent(getActivity(), WithdrawalActivity.class);
                startActivity(intent);
            }
        });

        
        return view;
    }
    @Override
    public void onResume(){
        super.onResume();
        MyData.getInstant();
        EditText accountName = view.findViewById(R.id.editAccount);
        String accountNameText = MyData.getInstant().getAccountName();
        accountName.setText(accountNameText);
        EditText accountNum = view.findViewById(R.id.balanceAmount);
        int accountNumber;
        accountNumber = MyData.getInstant().getAccountNum();
        String accountNasString;
        accountNasString = Integer.toString(accountNumber);
        accountNum.setText(accountNasString);
    }
}
