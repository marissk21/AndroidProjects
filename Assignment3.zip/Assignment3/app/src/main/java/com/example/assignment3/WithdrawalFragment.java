package com.example.assignment3;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class WithdrawalFragment extends Fragment {

View view;
    public WithdrawalFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_withdrawal, container, false);

        Button startDisplayAccountActivity = view.findViewById(R.id.withdrawalbutton);
        startDisplayAccountActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText withdrawmoney = view.findViewById(R.id.withdrawalEdit);
                String data =withdrawmoney.getText().toString();
                int money = Integer.parseInt(data);
                MyData.getInstant().withdrawMoney(money);
                Toast.makeText(getActivity(), getString(R.string.withdrawalmade), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), WithdrawalActivity.class);
                getActivity().finish();
            }
        });
        return view;
    }

}
