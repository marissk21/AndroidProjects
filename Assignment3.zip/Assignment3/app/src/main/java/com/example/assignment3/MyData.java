package com.example.assignment3;

import android.widget.Toast;

public final class MyData {
    private static MyData INSTANCE = null;
    private int accountNum;
    private String accountName;
    private int addMoney;
    private int withdrawalMoney;
    private String description = "";
    private MyData() {}

    public static MyData getInstant(){
        if (INSTANCE == null){
            INSTANCE = new MyData();
        }
        return INSTANCE;
    }
    public void setAccountNum(int num){
        accountNum =num;
    }
    public int getAccountNum(){
        return accountNum;
    }
    public void setAccountName(String name){
        accountName = name;
    }
    public String getAccountName(){
        return accountName;
    }
    public void depositMoney(int num){
        addMoney = num + accountNum;
        accountNum = addMoney;
    }
    public void withdrawMoney(int num){
        withdrawalMoney = accountNum - num;
        accountNum = withdrawalMoney;
    }
    public void setDescription(String name){ description = name; }
    public String getDescription(){return description;}
}
