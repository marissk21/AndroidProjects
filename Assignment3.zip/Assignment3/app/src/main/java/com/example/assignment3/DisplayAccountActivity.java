package com.example.assignment3;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Surface;

public class DisplayAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_account);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.nameBalance_container, new NameBalanceFragment());
        fragmentTransaction.commit();

        int rotation;
        rotation = getWindowManager().getDefaultDisplay().getRotation();
        if ((rotation == Surface.ROTATION_90) || (rotation == Surface.ROTATION_270))
        {
            FragmentManager fragmentManagerB = getSupportFragmentManager();
            FragmentTransaction fragmentTransactionB = fragmentManagerB.beginTransaction();
            fragmentTransactionB.replace(R.id.descriptionfragment_container, new DescriptionFragment());
            fragmentTransactionB.commit();
        }
    }
}
