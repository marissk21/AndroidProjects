package com.example.assignment3;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class DescriptionFragment extends Fragment {


    public DescriptionFragment() {
        // Required empty public constructor
    }

View view;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_description, container, false);
        EditText description = view.findViewById(R.id.descriptionText);
        String descrip = description.getText().toString();
        MyData.getInstant().setDescription(descrip);
        return view;
    }
    @Override
    public void onResume(){
        super.onResume();
        EditText description = view.findViewById(R.id.descriptionText);
        String descriptionText = MyData.getInstant().getDescription();
        description.setText(descriptionText);
    }
}
