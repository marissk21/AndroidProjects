package com.example.hw2_messages;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DataActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

       final EditText enteredText = (EditText) findViewById(R.id.editTextName);
        final EditText copiedText = (EditText) findViewById(R.id.copytext);
        Button Copy = (Button)findViewById(R.id.copyButton);
        Copy.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                copiedText.setText(enteredText.getText().toString());
            }
        });
            Button clearfieldbutton = findViewById(R.id.clearButton);
            clearfieldbutton.setOnClickListener( new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    copiedText.setText("");
                    enteredText.setText("");
                }
            });
    }

}
